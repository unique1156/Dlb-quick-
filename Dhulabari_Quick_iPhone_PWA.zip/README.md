# Dhulabari Quick — iPhone Install Version

## Install on iPhone
1. Put these files on a web host with HTTPS.
2. Open the hosted `index.html` URL in Safari.
3. Tap Share.
4. Tap **Add to Home Screen**.
5. Tap **Add**.
6. Launch **Dhulabari Quick** from the Home Screen.

### Important
A ZIP file cannot itself become an iPhone app. iOS requires the web app to be served from a web address for the PWA installation flow.

This version includes the iOS PWA metadata, manifest, icon and an in-app installation guide.

The prototype still stores data locally. A real public launch needs a backend/database, authentication, payments, maps/GPS and notifications.
